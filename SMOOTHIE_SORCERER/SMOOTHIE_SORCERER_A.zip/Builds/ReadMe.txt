Project Title - Smoothie Sorcerer

Project Version - V1.0

Project Description - A 3D top-down smoothie shop run by a witch and her cat as a cooking and farming management game.

Installation - Current build is for PC, but will branch to Android development in upcoming installments.

Controls - Use the mouse button to chop fruit while it is under the knife. The click must be in the bottom half of your screen. It is set this way to align with future UI choices and mobile development.

How To Play - Chopping at the right timing to gain points, if the chop is misaligned it will be worth less points.

Release Notes for Version 1.0
New Features
	Click to chop, has android dead zone placements for mobile testing.
Known Bugs /Issues
	"Good chop" recognition flashes if mouse button is held.
Numbered List of All Completed Features
	1. Click to chop
